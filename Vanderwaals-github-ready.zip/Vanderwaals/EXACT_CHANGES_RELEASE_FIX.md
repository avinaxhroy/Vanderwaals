# Exact Changes Made to Fix Release Build

## File: app/src/main/AndroidManifest.xml

### Change 1: Added Foreground Service Permissions

**Before:**
```xml
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

**After:**
```xml
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
```

---

### Change 2: Added SystemForegroundService Declaration

**Before:**
```xml
        <!-- WorkManager initialization provider -->
        <provider
            android:name="androidx.startup.InitializationProvider"
            android:authorities="${applicationId}.androidx-startup"
            android:exported="false"
            tools:node="merge">
            <meta-data
                android:name="androidx.work.WorkManagerInitializer"
                android:value="androidx.startup"
                tools:node="remove" />
        </provider>
    </application>
```

**After:**
```xml
        <!-- WorkManager initialization provider -->
        <provider
            android:name="androidx.startup.InitializationProvider"
            android:authorities="${applicationId}.androidx-startup"
            android:exported="false"
            tools:node="merge">
            <meta-data
                android:name="androidx.work.WorkManagerInitializer"
                android:value="androidx.startup"
                tools:node="remove" />
        </provider>

        <!-- SystemForegroundService for WorkManager -->
        <!-- CRITICAL: Specifies foreground service type for workers using setForegroundAsync() -->
        <!-- Used by BatchDownloadWorker for downloading wallpapers with dataSync foreground service type -->
        <service
            android:name="androidx.work.impl.foreground.SystemForegroundService"
            android:foregroundServiceType="dataSync"
            tools:replace="android:foregroundServiceType" />
    </application>
```

---

## Summary of Changes

| Component | Before | After | Status |
|-----------|--------|-------|--------|
| FOREGROUND_SERVICE permission | ❌ Missing | ✅ Added | FIXED |
| FOREGROUND_SERVICE_DATA_SYNC permission | ❌ Missing | ✅ Added | FIXED |
| SystemForegroundService declaration | ❌ Missing | ✅ Added | FIXED |
| foregroundServiceType attribute | ❌ Not declared | ✅ dataSync | FIXED |

---

## Test Results

### Before Fix
```
FAILURE: Build failed with an exception

Task :app:lintVitalRelease FAILED
Error: Missing dataSync foregroundServiceType in the AndroidManifest.xml
```

### After Fix
```
BUILD SUCCESSFUL in 788ms
```

---

## Lines Changed

- Lines added: 5 (permissions + service)
- Files modified: 1
- Code changes: 0
- Functionality impact: None
- Breaking changes: None
