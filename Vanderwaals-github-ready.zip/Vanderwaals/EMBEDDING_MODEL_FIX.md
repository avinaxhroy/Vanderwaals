# Embedding Model Fix - "Failed to extract embedding" Error

## Problem

When user uploads an image in **Personalized Mode**, the app shows:
```
Failed to extract embedding from scratch
```

## Root Cause

The TensorFlow Lite model file is missing:
```
app/src/main/assets/models/mobilenet_v3_small.tflite
```

Currently, only a **placeholder file** exists:
```
app/src/main/assets/models/mobilenet_v3_small.tflite.placeholder
```

The actual 2.9MB `.tflite` model file needs to be downloaded from TensorFlow Hub.

## Solution

### Option 1: Quick Download (Recommended)

```bash
cd /Users/avinash/Lab/Vanderwaals/Vanderwaals

# Download MobileNetV3-Small model from TensorFlow Hub
wget -O app/src/main/assets/models/mobilenet_v3_small.tflite \
  "https://tfhub.dev/google/lite-model/imagenet/mobilenet_v3_small_100_224/feature_vector/5?lite-format=tflite"
```

Or using `curl`:
```bash
curl -L -o app/src/main/assets/models/mobilenet_v3_small.tflite \
  "https://tfhub.dev/google/lite-model/imagenet/mobilenet_v3_small_100_224/feature_vector/5?lite-format=tflite"
```

### Option 2: Manual Download

1. Visit: https://tfhub.dev/google/lite-model/imagenet/mobilenet_v3_small_100_224/feature_vector/5
2. Download the `.tflite` file
3. Place it at: `app/src/main/assets/models/mobilenet_v3_small.tflite`
4. Remove the `.placeholder` file

### Option 3: Disable Personalized Mode (Temporary)

If you don't need personalized mode, you can temporarily disable it:

1. Open `ui/onboarding/ModeSelectionScreen.kt`
2. Comment out the "Personalize" card
3. Users will only see "Auto" mode

## Technical Details

### What is the model for?

The MobileNetV3-Small model extracts **576-dimensional embedding vectors** from images. These embeddings represent the aesthetic characteristics of wallpapers:
- Colors
- Composition
- Style
- Patterns

### How it's used

1. **User uploads sample wallpaper** → Extract embedding
2. **Compare with catalog embeddings** → Find similar wallpapers
3. **User likes/dislikes wallpapers** → Update preferences
4. **Select next wallpaper** → Match user's learned preferences

### Model Specifications

- **Name**: MobileNetV3-Small Feature Vector
- **Source**: TensorFlow Hub
- **Input**: 224x224 RGB image
- **Output**: 576-dimensional float array
- **Size**: 2.9 MB
- **Speed**: ~40ms on device
- **License**: Apache 2.0

## Verification

After downloading, verify the model loaded successfully:

### Check logs (adb logcat)

```bash
adb logcat | grep EmbeddingExtractor
```

**Expected output:**
```
D/EmbeddingExtractor: TFLite model loaded successfully
D/EmbeddingExtractor: Extracted 576-dimensional embedding in 42ms
```

**Error output (before fix):**
```
E/EmbeddingExtractor: Model file not found: models/mobilenet_v3_small.tflite. Please download the model.
W/EmbeddingExtractor: Cannot extract embedding: model not loaded
```

### Test in app

1. Open app
2. Select "Personalize" mode
3. Upload an image
4. Should see: "Processing..." → Success!
5. Should NOT see: "Failed to extract embedding"

## Why is the model not included?

Large binary files (2.9MB) are typically NOT committed to Git repositories because:
- Increases repository size significantly
- Slows down cloning/pulling
- Binary files don't diff well in version control
- GitHub has file size limits (100MB max)

Instead, we use:
- `.placeholder` file to mark the location
- Download script in documentation
- `.gitignore` entry to exclude the `.tflite` file

## Build Configuration

The model is excluded from Git in `.gitignore`:

```gitignore
# TensorFlow Lite models (download separately)
*.tflite
```

But it's INCLUDED in the APK build:

```gradle
// app/build.gradle.kts
android {
    ...
    sourceSets {
        getByName("main") {
            assets.srcDirs("src/main/assets")
        }
    }
}
```

## After Download

After downloading the model, the file structure should look like:

```
app/src/main/assets/
├── models/
│   ├── mobilenet_v3_small.tflite          ← NEW: Downloaded model (2.9 MB)
│   └── mobilenet_v3_small.tflite.placeholder  ← Can be deleted
└── sample-manifest.json
```

## Troubleshooting

### "wget: command not found"

Install wget:
```bash
# macOS
brew install wget

# Or use curl instead (pre-installed on macOS)
```

### "curl: (22) The requested URL returned error: 404"

The URL might have changed. Check TensorFlow Hub:
https://tfhub.dev/google/imagenet/mobilenet_v3_small_100_224/feature_vector/

### Model loads but extraction still fails

1. Check file size: `ls -lh app/src/main/assets/models/mobilenet_v3_small.tflite`
   - Should be ~2.9 MB
   - If much smaller, download was incomplete

2. Check file integrity:
   ```bash
   file app/src/main/assets/models/mobilenet_v3_small.tflite
   ```
   - Should say: "data" or "TensorFlow Lite model"

3. Rebuild app:
   ```bash
   ./gradlew clean assembleDebug
   ./gradlew installDebug
   ```

## Summary

**Issue:** Missing TensorFlow Lite model file  
**Cause:** Model not downloaded (only placeholder exists)  
**Fix:** Download model from TensorFlow Hub  
**Command:** 
```bash
wget -O app/src/main/assets/models/mobilenet_v3_small.tflite \
  "https://tfhub.dev/google/lite-model/imagenet/mobilenet_v3_small_100_224/feature_vector/5?lite-format=tflite"
```
**Result:** Personalized mode works, image upload succeeds

---

**Status:** ⚠️ **REQUIRES MANUAL DOWNLOAD**  
The model cannot be automatically fixed in code - it must be downloaded by the developer before building the app.
