# Background Workers Documentation

## Overview

This document describes the background processing infrastructure for the Vanderwaals wallpaper engine. The system uses **WorkManager** for reliable background task execution and **BroadcastReceiver** for system event handling.

All workers are integrated with **Hilt** for dependency injection and follow Android's best practices for background work.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     WorkScheduler                            │
│  (Singleton - Central scheduling & coordination)             │
└─────────────────────────────────────────────────────────────┘
                           │
           ┌───────────────┼───────────────┬─────────────┐
           ▼               ▼               ▼             ▼
    ┌──────────┐   ┌──────────────┐  ┌─────────┐  ┌──────────┐
    │ Catalog  │   │  Wallpaper   │  │  Batch  │  │ Cleanup  │
    │  Sync    │   │   Change     │  │Download │  │  Worker  │
    │ Worker   │   │   Worker     │  │ Worker  │  │          │
    └──────────┘   └──────────────┘  └─────────┘  └──────────┘
                           ▲
                           │
                   ┌───────────────┐
                   │ DeviceUnlock  │
                   │   Receiver    │
                   └───────────────┘
```

---

## Workers

### 1. CatalogSyncWorker

**Purpose:** Syncs the wallpaper catalog manifest from remote sources.

**Schedule:** Weekly (every 7 days)

**Location:** `me.avinas.vanderwaals.worker.CatalogSyncWorker`

**Features:**
- Downloads manifest.json from GitHub/jsDelivr
- Falls back to alternate source on failure
- Validates and stores manifest data
- Network constraint required

**Constraints:**
- Network: `CONNECTED`
- Battery: Not charging
- Backoff: Exponential (10 seconds initial)

**Dependencies:**
- `ManifestRepository` - Manifest data management

**Work Tags:**
- `CATALOG_SYNC_WORK`

**Retry Policy:**
```kotlin
setBackoffCriteria(
    BackoffPolicy.EXPONENTIAL,
    WorkRequest.MIN_BACKOFF_MILLIS,
    TimeUnit.MILLISECONDS
)
```

---

### 2. WallpaperChangeWorker

**Purpose:** Automatically changes wallpaper using Vanderwaals algorithm.

**Schedule:** Configurable (Daily, Every Unlock, or Custom Interval)

**Location:** `me.avinas.vanderwaals.worker.WallpaperChangeWorker`

**Features:**
- Uses `SelectNextWallpaperUseCase` for intelligent wallpaper selection
- Applies wallpaper to Home, Lock, or Both screens
- Updates wallpaper history
- Handles download if wallpaper not cached

**Input Parameters:**
- `KEY_SCREEN_TYPE` - "home", "lock", or "both"
- `KEY_ALBUM_NAME` - Target album (optional)

**Constraints:**
- Battery: Not low
- Storage: Not low

**Dependencies:**
- `SelectNextWallpaperUseCase` - Smart wallpaper selection
- `WallpaperRepository` - Download & cache management
- `PreferenceRepository` - User preferences
- `WallpaperManager` - Android system API

**Work Tags:**
- `WALLPAPER_CHANGE_WORK`

**Algorithm:**
1. Select next wallpaper using epsilon-greedy + cosine similarity
2. Download wallpaper if not cached
3. Apply to specified screen(s)
4. Record history
5. Report success/failure

---

### 3. BatchDownloadWorker

**Purpose:** Downloads top wallpapers in foreground with progress notifications.

**Schedule:** One-time, user-initiated

**Location:** `me.avinas.vanderwaals.worker.BatchDownloadWorker`

**Features:**
- **Foreground Service** - Shows persistent notification
- Downloads top 50 wallpapers based on user preferences
- Real-time progress updates
- Cancellation support
- Automatic cache management

**Input Parameters:**
- `KEY_MAX_COUNT` - Maximum wallpapers to download (default: 50)

**Constraints:**
- Network: `CONNECTED`
- Battery: Not low
- Storage: Not low

**Dependencies:**
- `WallpaperRepository` - Download management
- `PreferenceRepository` - Preference-based sorting

**Work Tags:**
- `BATCH_DOWNLOAD_WORK`

**Notification:**
- Channel: `batch_download_channel`
- Shows progress: X/Y downloaded
- Cancellable by user

**Foreground Service Type:**
```kotlin
ForegroundInfo(
    NOTIFICATION_ID,
    notification,
    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
)
```

---

### 4. CleanupWorker

**Purpose:** Daily maintenance - removes old history and disliked wallpapers.

**Schedule:** Daily (every 24 hours)

**Location:** `me.avinas.vanderwaals.worker.CleanupWorker`

**Features:**
- Deletes wallpaper history older than 30 days
- Removes disliked wallpapers from download queue
- Cleans up cached wallpaper files
- Low-priority execution

**Constraints:**
- Charging: Required
- Device Idle: Required
- Battery: Not low

**Dependencies:**
- `WallpaperRepository` - History & cache management
- `PreferenceRepository` - Disliked wallpaper tracking

**Work Tags:**
- `CLEANUP_WORK`

**Cleanup Rules:**
- History retention: 30 days
- Disliked wallpapers: Remove immediately
- Cache: Respect 450MB limit

---

## WorkScheduler

**Purpose:** Central coordinator for all background work.

**Location:** `me.avinas.vanderwaals.scheduler.WorkScheduler`

**Type:** Singleton (Hilt)

### Key Methods

#### `scheduleWallpaperChange(interval: ChangeInterval, screenType: String)`
Schedules periodic wallpaper changes.

**Intervals:**
```kotlin
enum class ChangeInterval {
    DAILY,           // 24 hours
    EVERY_UNLOCK     // On device unlock (via DeviceUnlockReceiver)
}
```

**Example:**
```kotlin
workScheduler.scheduleWallpaperChange(
    interval = ChangeInterval.DAILY,
    screenType = "both"
)
```

#### `triggerImmediateWallpaperChange(screenType: String)`
Triggers one-time immediate wallpaper change.

#### `scheduleBatchDownload(maxCount: Int)`
Starts foreground batch download.

#### `initializePeriodicWorkers()`
Initializes all periodic workers (catalog sync, cleanup).

**Called by:** Application.onCreate() or WorkManager initializer

---

## DeviceUnlockReceiver

**Purpose:** Listens for device unlock events to trigger wallpaper changes.

**Location:** `me.avinas.vanderwaals.receiver.DeviceUnlockReceiver`

**Trigger:** `ACTION_USER_PRESENT` broadcast

**Features:**
- Rate limiting (60 seconds between changes)
- SharedPreferences for last trigger time
- Uses `goAsync()` for coroutine work
- Delegates to `WorkScheduler`

**Manifest Entry:**
```xml
<receiver android:name="me.avinas.vanderwaals.receiver.DeviceUnlockReceiver"
    android:exported="false">
    <intent-filter>
        <action android:name="android.intent.action.USER_PRESENT" />
    </intent-filter>
</receiver>
```

**Rate Limiting:**
- Minimum interval: 60 seconds
- Storage: SharedPreferences (`device_unlock_prefs`)

**Usage:**
User enables "Every Unlock" interval → Receiver triggers wallpaper change on unlock.

---

## Hilt Integration

### WorkManagerModule

**Location:** `me.avinas.vanderwaals.di.WorkManagerModule`

Provides:
- `WorkManager` singleton instance

All workers use `@HiltWorker` annotation:
```kotlin
@HiltWorker
class CatalogSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val manifestRepository: ManifestRepository
) : CoroutineWorker(context, params)
```

### Configuration

WorkManager automatically uses `HiltWorkerFactory` when Hilt is configured:

1. Add dependency: `androidx.hilt:hilt-work`
2. Annotate Application class with `@HiltAndroidApp`
3. Workers are automatically injectable

---

## Work Tags Reference

| Worker               | Tag                      | Purpose                          |
|----------------------|--------------------------|----------------------------------|
| CatalogSyncWorker    | `CATALOG_SYNC_WORK`      | Unique identification            |
| WallpaperChangeWorker| `WALLPAPER_CHANGE_WORK`  | Cancel/query change work         |
| BatchDownloadWorker  | `BATCH_DOWNLOAD_WORK`    | Cancel/query download work       |
| CleanupWorker        | `CLEANUP_WORK`           | Query cleanup status             |

**Example:**
```kotlin
// Cancel all wallpaper change work
workManager.cancelAllWorkByTag("WALLPAPER_CHANGE_WORK")

// Query batch download status
val workInfos = workManager.getWorkInfosByTag("BATCH_DOWNLOAD_WORK").get()
```

---

## Notification Channels

### Batch Download Channel
- **ID:** `batch_download_channel`
- **Name:** "Batch Downloads"
- **Importance:** `IMPORTANCE_LOW`
- **Shows Progress:** Yes
- **Sound:** No

**Created by:** `BatchDownloadWorker`

---

## Integration Guide

### 1. Initialize on App Startup

```kotlin
@HiltAndroidApp
class VanderwaalsApp : Application() {
    
    @Inject
    lateinit var workScheduler: WorkScheduler
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize periodic workers
        workScheduler.initializePeriodicWorkers()
    }
}
```

### 2. Schedule Wallpaper Changes

```kotlin
// Daily wallpaper changes
workScheduler.scheduleWallpaperChange(
    interval = ChangeInterval.DAILY,
    screenType = "both"
)

// Change on unlock
workScheduler.scheduleWallpaperChange(
    interval = ChangeInterval.EVERY_UNLOCK,
    screenType = "home"
)
```

### 3. Trigger Immediate Change

```kotlin
// Immediate one-time change
workScheduler.triggerImmediateWallpaperChange(screenType = "lock")
```

### 4. Start Batch Download

```kotlin
// Download top 50 wallpapers
workScheduler.scheduleBatchDownload(maxCount = 50)
```

### 5. Cancel Work

```kotlin
// Cancel specific work
workManager.cancelAllWorkByTag("WALLPAPER_CHANGE_WORK")

// Cancel all work
workManager.cancelAllWork()
```

---

## Testing

### Unit Testing Workers

```kotlin
@Test
fun testCatalogSyncWorker() = runTest {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val worker = TestListenableWorkerBuilder<CatalogSyncWorker>(context)
        .build()
    
    val result = worker.doWork()
    
    assertEquals(Result.success(), result)
}
```

### Testing WorkScheduler

```kotlin
@Test
fun testScheduleWallpaperChange() {
    val workManager = WorkManager.getInstance(context)
    val scheduler = WorkScheduler(workManager)
    
    scheduler.scheduleWallpaperChange(
        interval = ChangeInterval.DAILY,
        screenType = "both"
    )
    
    val workInfos = workManager
        .getWorkInfosByTag("WALLPAPER_CHANGE_WORK")
        .get()
    
    assertEquals(1, workInfos.size)
    assertEquals(WorkInfo.State.ENQUEUED, workInfos[0].state)
}
```

### Testing DeviceUnlockReceiver

```kotlin
@Test
fun testDeviceUnlockReceiver() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val intent = Intent(Intent.ACTION_USER_PRESENT)
    val receiver = DeviceUnlockReceiver()
    
    receiver.onReceive(context, intent)
    
    // Verify WorkScheduler triggered
    val workInfos = WorkManager.getInstance(context)
        .getWorkInfosByTag("WALLPAPER_CHANGE_WORK")
        .get()
    
    assertTrue(workInfos.isNotEmpty())
}
```

---

## Troubleshooting

### Worker Not Running

**Symptoms:** Scheduled work doesn't execute

**Causes:**
- Battery saver mode enabled
- App in Doze mode
- Constraints not met (network, storage, battery)

**Solutions:**
```kotlin
// Check work status
val workInfos = workManager
    .getWorkInfosForUniqueWork("wallpaper_change_work")
    .get()

workInfos.forEach { workInfo ->
    Log.d("WorkStatus", "State: ${workInfo.state}")
    Log.d("WorkStatus", "Run attempt: ${workInfo.runAttemptCount}")
}
```

### Wallpaper Not Changing on Unlock

**Symptoms:** DeviceUnlockReceiver not triggering

**Causes:**
- Receiver not registered in manifest
- Rate limiting (60s cooldown)
- WorkScheduler not initialized

**Solutions:**
1. Verify manifest entry
2. Check SharedPreferences for `last_unlock_trigger_time`
3. Clear app data to reset rate limiter

### Batch Download Stuck

**Symptoms:** Progress notification frozen

**Causes:**
- Network connectivity lost
- Storage full
- Worker cancelled

**Solutions:**
```kotlin
// Check download work status
val workInfo = workManager
    .getWorkInfosByTag("BATCH_DOWNLOAD_WORK")
    .get()
    .firstOrNull()

when (workInfo?.state) {
    WorkInfo.State.RUNNING -> Log.d("Download", "In progress")
    WorkInfo.State.FAILED -> Log.e("Download", "Failed: ${workInfo.outputData}")
    WorkInfo.State.CANCELLED -> Log.w("Download", "Cancelled by user")
}
```

---

## Performance Considerations

### Battery Impact

- **CatalogSyncWorker:** Minimal (weekly, small download)
- **WallpaperChangeWorker:** Low (quick operation, < 5 seconds)
- **BatchDownloadWorker:** Medium (large downloads, user-initiated)
- **CleanupWorker:** Minimal (runs when charging & idle)

### Network Usage

- Catalog sync: ~5-10 KB/week
- Wallpaper change: ~2-5 MB/change (if not cached)
- Batch download: ~100-250 MB (50 wallpapers)

### Storage Management

- Cache limit: 450 MB (enforced by WallpaperRepository)
- History retention: 30 days
- Automatic cleanup: Daily

---

## Future Enhancements

### Potential Improvements

1. **Adaptive Scheduling**
   - Adjust frequency based on user engagement
   - Learn optimal change times

2. **Smart Prefetching**
   - Pre-download likely next wallpapers
   - Reduce latency on wallpaper change

3. **Network Optimization**
   - Use `UNMETERED` constraint for large downloads
   - Implement progressive image loading

4. **Advanced Analytics**
   - Track worker success rates
   - Monitor battery/network impact
   - Report to Firebase Analytics

5. **WorkManager Diagnostics**
   - Built-in diagnostic UI
   - Export work logs
   - Real-time work status dashboard

---

## Dependencies

### Required Libraries

```gradle
// WorkManager
implementation("androidx.work:work-runtime-ktx:2.9.0")

// Hilt WorkManager Integration
implementation("androidx.hilt:hilt-work:1.1.0")
kapt("androidx.hilt:hilt-compiler:1.1.0")

// Coroutines
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
```

### Permissions

```xml
<!-- WorkManager -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />

<!-- Wallpaper -->
<uses-permission android:name="android.permission.SET_WALLPAPER" />

<!-- Notifications -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<!-- Boot receiver (for WorkManager initialization) -->
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
```

---

## References

- [WorkManager Documentation](https://developer.android.com/topic/libraries/architecture/workmanager)
- [Hilt WorkManager Integration](https://developer.android.com/training/dependency-injection/hilt-jetpack#workmanager)
- [VanderwaalsStrategy.md](./VanderwaalsStrategy.md)
- [Background Work Guide](https://developer.android.com/guide/background)

---

## Summary

The background worker infrastructure provides:

✅ **Reliable Scheduling** - WorkManager handles constraints & retries  
✅ **Smart Wallpaper Selection** - Vanderwaals algorithm integration  
✅ **User Control** - Configurable intervals & manual triggers  
✅ **Battery Efficient** - Respects device state & user preferences  
✅ **Maintainable** - Clean architecture with Hilt dependency injection  

All workers are production-ready and follow Android best practices for background work.
