# ✅ FIX: "Run workflow" Button Not Showing

## The Problem

The "Run workflow" button is missing because:
- ❌ The workflow file (`.github/workflows/curate.yml`) is NOT committed to git
- ❌ The scripts folder is NOT committed to git
- ✅ They exist locally but GitHub doesn't know about them

## Solution: Commit and Push

### Step 1: Add the files to git

```bash
cd /Users/avinash/Lab/Vanderwaals/Vanderwaals

# Add the workflow file
git add .github/workflows/curate.yml

# Add the scripts folder
git add scripts/

# Verify what's staged
git status
```

**Expected output:**
```
On branch master
Changes to be committed:
  new file:   .github/workflows/curate.yml
  new file:   scripts/curate_wallpapers.py
  new file:   scripts/requirements.txt
```

### Step 2: Commit the changes

```bash
git commit -m "feat: add automated wallpaper curation pipeline with sparse checkout and error handling"
```

### Step 3: Push to GitHub

```bash
git push origin master
```

**Expected output:**
```
Enumerating objects: 10, done.
Counting objects: 100% (10/10), done.
Delta compression using 2 threads
To github.com:avinaxhroy/Vanderwaals.git
   66c3a4b..abc1234 master -> master
```

## Step 4: Verify in GitHub

1. Go to: https://github.com/avinaxhroy/Vanderwaals

2. Click **Actions** tab

3. Click **"Curate Wallpapers"** 

4. ✅ **NOW you should see the "Run workflow" button!**

## If Still Not Showing

### Refresh GitHub
- Hard refresh: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)
- Wait 2-3 minutes for GitHub to sync
- Close and reopen the Actions page

### Check Workflow Syntax
The workflow file must be valid YAML:
```bash
# Check for syntax errors locally
cd /Users/avinash/Lab/Vanderwaals/Vanderwaals
cat .github/workflows/curate.yml
```

### Verify File Location
Must be EXACTLY: `.github/workflows/curate.yml`
```bash
# Confirm it's in the right place
ls -la .github/workflows/curate.yml
```

## Complete Commands (Copy & Paste)

```bash
cd /Users/avinash/Lab/Vanderwaals/Vanderwaals && \
git add .github/workflows/curate.yml scripts/ && \
git commit -m "feat: add automated wallpaper curation pipeline with sparse checkout and error handling" && \
git push origin master && \
echo "✅ Done! Check GitHub Actions in 30 seconds"
```

## Next Steps After "Run workflow" Appears

1. Go to https://github.com/avinaxhroy/Vanderwaals/actions
2. Click "Curate Wallpapers"
3. Click **"Run workflow"** button (top right)
4. **Check "Test mode"** ✓
5. Click **"Run workflow"** (green button)
6. Watch the logs in real-time

---

**TL;DR:**
```bash
cd /Users/avinash/Lab/Vanderwaals/Vanderwaals
git add .github/workflows/curate.yml scripts/
git commit -m "feat: add curation pipeline"
git push origin master
```

Then refresh GitHub and the "Run workflow" button will appear! 🚀
