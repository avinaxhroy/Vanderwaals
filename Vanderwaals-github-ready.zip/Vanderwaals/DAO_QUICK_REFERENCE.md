# Quick Reference: DAO Methods

## WallpaperMetadataDao (18 methods)

### Insert/Update
```kotlin
insertAll(wallpapers: List<WallpaperMetadata>) // Bulk insert from manifest
insert(wallpaper: WallpaperMetadata) // Single insert
update(wallpaper: WallpaperMetadata) // Update existing
```

### Query (Reactive - Flow)
```kotlin
getAll(): Flow<List<WallpaperMetadata>> // All wallpapers
getByCategory(category: String): Flow<List<WallpaperMetadata>> // Filter by category
getBySource(source: String): Flow<List<WallpaperMetadata>> // Filter by source
getAllCategories(): Flow<List<String>> // Unique categories
```

### Query (One-shot - Suspend)
```kotlin
getAllOnce(): List<WallpaperMetadata> // Background processing
getById(id: String): WallpaperMetadata? // Single lookup
getByIds(ids: List<String>): List<WallpaperMetadata> // Batch lookup
getByBrightnessRange(min: Int, max: Int): List<WallpaperMetadata> // Brightness filter
getAllSources(): List<String> // Unique sources
```

### Delete
```kotlin
delete(id: String) // Delete by ID
deleteBySource(source: String) // Bulk delete
deleteAll() // Clear all
```

### Stats
```kotlin
getCount(): Int // Total count
getCountByCategory(category: String): Int // Category count
```

---

## UserPreferenceDao (10 methods)

### Insert/Update
```kotlin
insert(preferences: UserPreferences) // Initialize (singleton)
update(preferences: UserPreferences) // Full update
```

### Query
```kotlin
get(): Flow<UserPreferences?> // Reactive preferences
getOnce(): UserPreferences? // One-shot
exists(): Boolean // Check initialization
```

### Atomic Updates
```kotlin
incrementFeedbackCount(timestamp: Long) // Feedback counter
switchMode(mode: String, timestamp: Long) // Auto/personalized
updateEpsilon(epsilon: Float, timestamp: Long) // Exploration rate
resetFeedback(timestamp: Long) // Reset for re-personalization
```

### Delete
```kotlin
deleteAll() // Clear preferences
```

---

## WallpaperHistoryDao (20 methods)

### Insert/Update
```kotlin
insert(history: WallpaperHistory): Long // Returns ID
insertAll(histories: List<WallpaperHistory>): List<Long> // Batch
update(history: WallpaperHistory) // Full update
```

### Query (Reactive - Flow)
```kotlin
getHistory(): Flow<List<WallpaperHistory>> // Last 100 entries
getDownloadedWallpapers(): Flow<List<WallpaperHistory>> // Downloaded only
```

### Query (One-shot - Suspend)
```kotlin
getHistoryOnce(): List<WallpaperHistory> // Last 100 entries
getActiveWallpaper(): WallpaperHistory? // Current (removedAt = null)
getById(id: Long): WallpaperHistory? // Single entry
getByWallpaperId(wallpaperId: String): List<WallpaperHistory> // All for wallpaper
hasBeenApplied(wallpaperId: String): Boolean // Duplicate check
getEntriesWithFeedback(): List<WallpaperHistory> // Explicit feedback only
getFeedbackStats(): Map<String, Int> // Feedback counts
```

### Atomic Updates
```kotlin
markRemoved(id: Long, timestamp: Long) // Set removal time
setFeedback(id: Long, feedback: String) // Set like/dislike
markDownloaded(id: Long) // Set download flag
```

### Delete
```kotlin
delete(id: Long) // Delete by ID
deleteByWallpaperId(wallpaperId: String) // Delete all for wallpaper
cleanupOldEntries() // Keep last 100
deleteAll() // Clear history
```

### Stats
```kotlin
getCount(): Int // Total count
```

---

## DownloadQueueDao (25 methods)

### Insert/Update
```kotlin
insertAll(items: List<DownloadQueueItem>) // Populate/re-rank queue
insert(item: DownloadQueueItem) // Single insert
update(item: DownloadQueueItem) // Full update
```

### Query (Reactive - Flow)
```kotlin
getQueue(): Flow<List<DownloadQueueItem>> // All ordered by priority
getDownloaded(): Flow<List<DownloadQueueItem>> // Downloaded only
```

### Query (One-shot - Suspend)
```kotlin
getQueueOnce(): List<DownloadQueueItem> // All ordered by priority
getTopUndownloaded(limit: Int): List<DownloadQueueItem> // ⭐ Primary download query
getByWallpaperId(wallpaperId: String): DownloadQueueItem? // Single item
getRetryableItems(): List<DownloadQueueItem> // Ready for retry
getFailedItems(): List<DownloadQueueItem> // Max retries exceeded
```

### Atomic Updates
```kotlin
markDownloaded(wallpaperId: String) // Set downloaded flag
incrementRetryCount(wallpaperId: String) // Failed attempt
resetRetryCount(wallpaperId: String) // Reset after success
updatePriority(wallpaperId: String, priority: Float) // Update similarity
```

### Delete
```kotlin
delete(wallpaperId: String) // Delete by ID
deleteDownloaded() // Cleanup completed
deleteFailed() // Remove failed items
deleteBelowThreshold(threshold: Float) // Remove low-priority
deleteAll() // Clear queue
keepTopN(limit: Int) // Maintain size limit
```

### Stats
```kotlin
getCount(): Int // Total count
getDownloadedCount(): Int // Downloaded count
getPendingCount(): Int // Pending count
isInQueue(wallpaperId: String): Boolean // Existence check
isDownloaded(wallpaperId: String): Boolean? // Download status
```

---

## Common Patterns

### Initialize on First Launch
```kotlin
suspend fun initialize() {
    if (!userPreferenceDao.exists()) {
        userPreferenceDao.insert(UserPreferences.createDefault())
    }
}
```

### Load Data Reactively
```kotlin
val history: StateFlow<List<WallpaperHistory>> = historyDao
    .getHistory()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
```

### Apply Wallpaper
```kotlin
suspend fun applyWallpaper(wallpaperId: String) {
    // Mark previous as removed
    historyDao.getActiveWallpaper()?.let { active ->
        historyDao.markRemoved(active.id, System.currentTimeMillis())
    }
    
    // Insert new history entry
    val historyId = historyDao.insert(
        WallpaperHistory(
            wallpaperId = wallpaperId,
            appliedAt = System.currentTimeMillis(),
            removedAt = null,
            userFeedback = null,
            downloadedToStorage = false
        )
    )
    
    // Apply wallpaper...
}
```

### Record Feedback
```kotlin
suspend fun likeWallpaper(historyId: Long) {
    // Update history
    historyDao.setFeedback(historyId, WallpaperHistory.FEEDBACK_LIKE)
    
    // Update preferences
    val prefs = userPreferenceDao.getOnce() ?: return
    val wallpaper = getWallpaperFromHistory(historyId)
    
    val updatedVector = applyEMA(
        prefs.preferenceVector,
        wallpaper.embedding,
        learningRate = 0.15f
    )
    
    val updated = prefs.copy(
        preferenceVector = updatedVector,
        likedWallpaperIds = prefs.likedWallpaperIds + wallpaper.id,
        feedbackCount = prefs.feedbackCount + 1,
        lastUpdated = System.currentTimeMillis()
    )
    
    userPreferenceDao.update(updated)
    
    // Re-rank queue
    reRankQueue(updatedVector)
}
```

### Download Worker
```kotlin
suspend fun downloadWallpapers() {
    val toDownload = downloadQueueDao.getTopUndownloaded(limit = 10)
    
    toDownload.forEach { item ->
        try {
            downloadWallpaper(item.wallpaperId)
            downloadQueueDao.markDownloaded(item.wallpaperId)
        } catch (e: Exception) {
            downloadQueueDao.incrementRetryCount(item.wallpaperId)
            
            val updated = downloadQueueDao.getByWallpaperId(item.wallpaperId)
            if (updated?.shouldRetry() == true) {
                scheduleRetry(item.wallpaperId, updated.getRetryDelayMs())
            }
        }
    }
}
```

### Re-rank Queue
```kotlin
suspend fun reRankQueue(preferenceVector: FloatArray) {
    val allWallpapers = wallpaperMetadataDao.getAllOnce()
    
    val reranked = allWallpapers
        .map { wallpaper ->
            val similarity = cosineSimilarity(preferenceVector, wallpaper.embedding)
            DownloadQueueItem.create(wallpaper.id, similarity)
        }
        .sortedByDescending { it.priority }
        .take(50)
    
    downloadQueueDao.deleteAll()
    downloadQueueDao.insertAll(reranked)
}
```

### Cleanup History
```kotlin
suspend fun cleanupHistory() {
    historyDao.cleanupOldEntries() // Keeps last 100
}
```

### Sync Manifest
```kotlin
suspend fun syncManifest() {
    val manifest = downloadManifest()
    
    // Update metadata
    wallpaperMetadataDao.deleteAll()
    wallpaperMetadataDao.insertAll(manifest.wallpapers)
    
    // Re-rank queue with new wallpapers
    val prefs = userPreferenceDao.getOnce() ?: return
    reRankQueue(prefs.preferenceVector)
}
```

---

## Key Constants

### UserPreferences
```kotlin
UserPreferences.MODE_AUTO = "auto"
UserPreferences.MODE_PERSONALIZED = "personalized"
UserPreferences.DEFAULT_EPSILON = 0.1f
```

### WallpaperHistory
```kotlin
WallpaperHistory.FEEDBACK_LIKE = "like"
WallpaperHistory.FEEDBACK_DISLIKE = "dislike"
WallpaperHistory.MAX_HISTORY_ENTRIES = 100
WallpaperHistory.IMPLICIT_DISLIKE_THRESHOLD_MS = 5 * 60 * 1000L // 5 min
WallpaperHistory.IMPLICIT_LIKE_THRESHOLD_MS = 24 * 60 * 60 * 1000L // 24 hours
```

### DownloadQueueItem
```kotlin
DownloadQueueItem.MAX_RETRY_COUNT = 3
DownloadQueueItem.RETRY_BASE_DELAY_MS = 5000L // 5 seconds
DownloadQueueItem.MAX_QUEUE_SIZE = 50
DownloadQueueItem.MIN_PRIORITY_THRESHOLD = 0.3f
```

---

## Performance Tips

1. **Use Flow for UI updates:**
   ```kotlin
   dao.getHistory().collect { history -> updateUI(history) }
   ```

2. **Use suspend for background work:**
   ```kotlin
   val wallpapers = dao.getAllOnce() // One-shot query
   ```

3. **Use atomic updates:**
   ```kotlin
   dao.markRemoved(id, timestamp) // Better than full update
   ```

4. **Batch operations:**
   ```kotlin
   dao.insertAll(wallpapers) // Single transaction
   ```

5. **Cleanup regularly:**
   ```kotlin
   historyDao.cleanupOldEntries() // After each insert
   downloadQueueDao.keepTopN(50) // Maintain size limit
   ```

6. **Index usage:**
   - Filter by indexed columns (category, source, brightness, priority)
   - Avoid full table scans where possible

---

## Injection Example

```kotlin
@HiltViewModel
class WallpaperViewModel @Inject constructor(
    private val wallpaperMetadataDao: WallpaperMetadataDao,
    private val userPreferenceDao: UserPreferenceDao,
    private val wallpaperHistoryDao: WallpaperHistoryDao,
    private val downloadQueueDao: DownloadQueueDao
) : ViewModel() {
    
    val wallpapers = wallpaperMetadataDao.getAll()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    val history = wallpaperHistoryDao.getHistory()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    val preferences = userPreferenceDao.get()
        .stateIn(viewModelScope, SharingStarted.Lazily, null)
}
```

---

## Summary

- **73 DAO methods** across 4 DAOs
- **Reactive queries** with Flow for UI
- **Suspend functions** for background work
- **Atomic updates** for performance
- **Auto-cleanup** for history and queue
- **Comprehensive documentation** on all methods

Ready to use! 🚀
