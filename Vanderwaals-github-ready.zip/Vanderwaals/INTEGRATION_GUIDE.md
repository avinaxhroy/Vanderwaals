# Integration and Migration Guide

This guide helps you integrate the enhanced algorithms into your existing Vanderwaals app.

## 🗄️ Database Migration Required

### Step 1: Update UserPreferences Table
Add `momentumVector` column:

```kotlin
// In your Room migration
@Database(
    entities = [
        UserPreferences::class,
        WallpaperMetadata::class,
        CategoryPreference::class, // NEW
        WallpaperHistory::class
    ],
    version = 2, // Increment version
    exportSchema = true
)
abstract class VanderwaalsDatabase : RoomDatabase() {
    // ... DAOs
}
```

```kotlin
// Create migration
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        // Add momentumVector column to user_preferences
        // Store as BLOB (FloatArray serialized)
        database.execSQL(
            "ALTER TABLE user_preferences ADD COLUMN momentumVector BLOB NOT NULL DEFAULT X''"
        )
        
        // Create category_preferences table
        database.execSQL("""
            CREATE TABLE IF NOT EXISTS category_preferences (
                category TEXT PRIMARY KEY NOT NULL,
                likes INTEGER NOT NULL DEFAULT 0,
                dislikes INTEGER NOT NULL DEFAULT 0,
                views INTEGER NOT NULL DEFAULT 0,
                lastShown INTEGER NOT NULL DEFAULT 0
            )
        """)
        
        // Create indexes for category_preferences
        database.execSQL(
            "CREATE INDEX IF NOT EXISTS index_category_preferences_lastShown ON category_preferences(lastShown)"
        )
    }
}

// Add migration to database builder
val database = Room.databaseBuilder(
    context.applicationContext,
    VanderwaalsDatabase::class.java,
    "vanderwaals_db"
)
    .addMigrations(MIGRATION_1_2)
    .build()
```

### Step 2: Create CategoryPreference DAO

```kotlin
@Dao
interface CategoryPreferenceDao {
    @Query("SELECT * FROM category_preferences WHERE category = :category")
    suspend fun getByCategory(category: String): CategoryPreference?
    
    @Query("SELECT * FROM category_preferences")
    suspend fun getAll(): List<CategoryPreference>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(categoryPreference: CategoryPreference)
    
    @Transaction
    suspend fun incrementViews(category: String) {
        val current = getByCategory(category) ?: CategoryPreference(category = category)
        insert(current.copy(
            views = current.views + 1,
            lastShown = System.currentTimeMillis()
        ))
    }
    
    @Transaction
    suspend fun incrementLikes(category: String) {
        val current = getByCategory(category) ?: CategoryPreference(category = category)
        insert(current.copy(likes = current.likes + 1))
    }
    
    @Transaction
    suspend fun incrementDislikes(category: String) {
        val current = getByCategory(category) ?: CategoryPreference(category = category)
        insert(current.copy(dislikes = current.dislikes + 1))
    }
    
    @Query("DELETE FROM category_preferences")
    suspend fun deleteAll()
}
```

---

## 🔌 Dependency Injection (Hilt)

### Step 1: Provide New Components

```kotlin
@Module
@InstallIn(SingletonComponent::class)
object AlgorithmModule {
    
    @Provides
    @Singleton
    fun provideSimilarityCalculator(): SimilarityCalculator {
        return SimilarityCalculator()
    }
    
    @Provides
    @Singleton
    fun providePreferenceUpdater(): PreferenceUpdater {
        return PreferenceUpdater()
    }
    
    @Provides
    @Singleton
    fun provideExplorationStrategies(): ExplorationStrategies {
        return ExplorationStrategies()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    fun provideCategoryPreferenceDao(database: VanderwaalsDatabase): CategoryPreferenceDao {
        return database.categoryPreferenceDao()
    }
}
```

---

## 🎨 UI Integration

### Step 1: Update History Screen (Feedback Buttons)

```kotlin
@Composable
fun HistoryItem(
    wallpaper: WallpaperMetadata,
    onLike: (WallpaperMetadata) -> Unit,
    onDislike: (WallpaperMetadata) -> Unit,
    onDownload: (WallpaperMetadata) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Wallpaper preview
            GlideImage(
                imageModel = { wallpaper.thumbnailUrl },
                modifier = Modifier.size(80.dp)
            )
            
            // Action buttons
            Row {
                IconButton(onClick = { onLike(wallpaper) }) {
                    Icon(Icons.Default.Favorite, "Like")
                }
                IconButton(onClick = { onDislike(wallpaper) }) {
                    Icon(Icons.Default.ThumbDown, "Dislike")
                }
                IconButton(onClick = { onDownload(wallpaper) }) {
                    Icon(Icons.Default.Download, "Download")
                }
            }
        }
    }
}
```

### Step 2: Update ViewModel

```kotlin
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val updatePreferencesUseCase: UpdatePreferencesUseCase,
    private val categoryPreferenceDao: CategoryPreferenceDao,
    private val historyRepository: HistoryRepository
) : ViewModel() {
    
    fun onLikeWallpaper(wallpaper: WallpaperMetadata) {
        viewModelScope.launch {
            // Update preferences with momentum
            val result = updatePreferencesUseCase(
                wallpaper = wallpaper,
                feedback = FeedbackType.LIKE
            )
            
            result.fold(
                onSuccess = {
                    // Update category preferences
                    categoryPreferenceDao.incrementLikes(wallpaper.category)
                    
                    // Show feedback
                    _uiState.value = UiState.Success("Preferences updated ❤️")
                },
                onFailure = { error ->
                    _uiState.value = UiState.Error("Failed: ${error.message}")
                }
            )
        }
    }
    
    fun onDislikeWallpaper(wallpaper: WallpaperMetadata) {
        viewModelScope.launch {
            val result = updatePreferencesUseCase(
                wallpaper = wallpaper,
                feedback = FeedbackType.DISLIKE
            )
            
            result.fold(
                onSuccess = {
                    categoryPreferenceDao.incrementDislikes(wallpaper.category)
                    _uiState.value = UiState.Success("Won't show similar 👎")
                },
                onFailure = { error ->
                    _uiState.value = UiState.Error("Failed: ${error.message}")
                }
            )
        }
    }
}
```

---

## 🔄 Worker Integration

### Update WallpaperChangeWorker

```kotlin
@HiltWorker
class WallpaperChangeWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val selectNextWallpaperUseCase: SelectNextWallpaperUseCase,
    private val categoryPreferenceDao: CategoryPreferenceDao,
    private val historyRepository: HistoryRepository
) : CoroutineWorker(context, workerParams) {
    
    override suspend fun doWork(): Result {
        return try {
            // Select next wallpaper (uses all enhancements automatically)
            val result = selectNextWallpaperUseCase()
            
            result.fold(
                onSuccess = { wallpaper ->
                    // Apply wallpaper
                    applyWallpaper(wallpaper)
                    
                    // Record history
                    historyRepository.insert(WallpaperHistory(
                        wallpaperId = wallpaper.id,
                        appliedAt = System.currentTimeMillis()
                    ))
                    
                    // Update category statistics
                    categoryPreferenceDao.incrementViews(wallpaper.category)
                    
                    Result.success()
                },
                onFailure = { error ->
                    Log.e(TAG, "Failed to select wallpaper: ${error.message}")
                    Result.retry()
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Worker error: ${e.message}", e)
            Result.failure()
        }
    }
    
    private suspend fun applyWallpaper(wallpaper: WallpaperMetadata) {
        // Download and apply wallpaper using existing logic
        // ...
    }
    
    companion object {
        private const val TAG = "WallpaperChangeWorker"
    }
}
```

---

## 🧪 Testing

### Step 1: Test Similarity Calculator

```kotlin
@Test
fun testCompositeSimilarity() {
    val calculator = SimilarityCalculator()
    
    // Create test wallpaper
    val wallpaper = WallpaperMetadata(
        id = "test",
        url = "https://example.com/test.jpg",
        thumbnailUrl = "https://example.com/test_thumb.jpg",
        source = "github",
        category = "nature",
        colors = listOf("#FF5733", "#282828", "#98971a"),
        brightness = 65,
        contrast = 55,
        embedding = FloatArray(1024) { Random.nextFloat() },
        resolution = "1920x1080",
        attribution = "Test"
    )
    
    val userEmbedding = FloatArray(1024) { Random.nextFloat() }
    val userColors = listOf("#FA7233", "#2A2A2A", "#9A9722")
    
    val score = calculator.calculateCompositeSimilarity(
        userEmbedding = userEmbedding,
        userColors = userColors,
        userCategory = "nature",
        userBrightness = 60,
        userContrast = 50,
        wallpaper = wallpaper
    )
    
    // Score should be between 0 and 1
    assertTrue(score >= 0f && score <= 1f)
}
```

### Step 2: Test Preference Updates

```kotlin
@Test
fun testMomentumUpdate() {
    val updater = PreferenceUpdater()
    
    val currentVector = FloatArray(1024) { 0.5f }
    val targetEmbedding = FloatArray(1024) { 0.7f }
    val momentum = FloatArray(1024) { 0f }
    
    // First update
    val (updated1, momentum1) = updater.updateWithPositiveFeedback(
        currentVector = currentVector,
        targetEmbedding = targetEmbedding,
        learningRate = 0.15f,
        momentum = momentum
    )
    
    // Second update
    val (updated2, momentum2) = updater.updateWithPositiveFeedback(
        currentVector = updated1,
        targetEmbedding = targetEmbedding,
        learningRate = 0.15f,
        momentum = momentum1
    )
    
    // Preference should move toward target
    assertTrue(updated2[0] > updated1[0])
    assertTrue(updated2[0] > currentVector[0])
}
```

### Step 3: Test Category Tracking

```kotlin
@Test
fun testCategoryPreference() = runTest {
    val dao = database.categoryPreferenceDao()
    
    // Increment views
    dao.incrementViews("nature")
    dao.incrementViews("nature")
    
    // Increment likes
    dao.incrementLikes("nature")
    
    // Verify
    val category = dao.getByCategory("nature")
    assertNotNull(category)
    assertEquals(2, category?.views)
    assertEquals(1, category?.likes)
    assertEquals(0, category?.dislikes)
    
    // Check score
    val score = category?.calculateScore() ?: 0f
    assertTrue(score > 0f) // Positive score (more likes than dislikes)
}
```

---

## 📊 Monitoring and Analytics

### Step 1: Track Algorithm Performance

```kotlin
object AlgorithmAnalytics {
    
    fun logSimilarityScore(
        wallpaperId: String,
        score: Float,
        useComposite: Boolean
    ) {
        Log.d("Algorithm", "Similarity score for $wallpaperId: $score (composite: $useComposite)")
        // Send to analytics service (Firebase, etc.)
    }
    
    fun logPreferenceUpdate(
        feedbackType: FeedbackType,
        learningRate: Float,
        feedbackCount: Int
    ) {
        Log.d("Algorithm", "Preference update: $feedbackType at rate $learningRate (count: $feedbackCount)")
    }
    
    fun logSelectionQuality(
        wallpaperId: String,
        qualityScore: Float,
        diversityScore: Float,
        method: String // "epsilon-greedy", "UCB", "diversity"
    ) {
        Log.d("Algorithm", "Selected $wallpaperId via $method (quality: $qualityScore, diversity: $diversityScore)")
    }
}
```

### Step 2: Monitor Category Balance

```kotlin
@Composable
fun CategoryStatsScreen(viewModel: StatsViewModel = hiltViewModel()) {
    val categories by viewModel.categoryStats.collectAsState()
    
    LazyColumn {
        items(categories) { category ->
            CategoryStatsItem(
                category = category.category,
                likes = category.likes,
                dislikes = category.dislikes,
                views = category.views,
                score = category.calculateScore()
            )
        }
    }
}

@Composable
fun CategoryStatsItem(
    category: String,
    likes: Int,
    dislikes: Int,
    views: Int,
    score: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(category)
        Text("❤️ $likes 👎 $dislikes 👁 $views")
        Text("Score: ${String.format("%.2f", score)}")
    }
}
```

---

## 🐛 Troubleshooting

### Issue: Migration Fails
**Solution:** Check database version and migration path
```kotlin
// Verify migration is applied
database.openHelper.writableDatabase
// Check schema version
```

### Issue: Momentum Not Persisting
**Solution:** Verify TypeConverter for FloatArray
```kotlin
class Converters {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(value.size * 4)
        value.forEach { buffer.putFloat(it) }
        return buffer.array()
    }
    
    @TypeConverter
    fun toFloatArray(value: ByteArray): FloatArray {
        val buffer = ByteBuffer.wrap(value)
        return FloatArray(value.size / 4) { buffer.getFloat() }
    }
}
```

### Issue: Category Stats Not Updating
**Solution:** Ensure DAO methods are called
```kotlin
// After wallpaper selection
categoryPreferenceDao.incrementViews(wallpaper.category)

// After user feedback
when (feedback) {
    FeedbackType.LIKE -> categoryPreferenceDao.incrementLikes(wallpaper.category)
    FeedbackType.DISLIKE -> categoryPreferenceDao.incrementDislikes(wallpaper.category)
}
```

---

## ✅ Integration Checklist

- [ ] Database migration created and tested
- [ ] CategoryPreference entity added
- [ ] CategoryPreferenceDao created
- [ ] Hilt modules updated
- [ ] UI updated with feedback buttons
- [ ] ViewModel updated with new use cases
- [ ] Worker updated to track categories
- [ ] Tests written and passing
- [ ] Analytics/logging added
- [ ] Documentation updated
- [ ] Code reviewed
- [ ] Performance tested
- [ ] Released to beta testers

---

## 🎯 Rollout Strategy

### Phase 1: Internal Testing (Week 1)
- [ ] Deploy to dev environment
- [ ] Test all algorithm components
- [ ] Verify database migration
- [ ] Monitor performance metrics
- [ ] Fix any issues

### Phase 2: Beta Testing (Week 2-3)
- [ ] Deploy to beta channel
- [ ] Collect user feedback
- [ ] Monitor analytics
- [ ] Fine-tune parameters
- [ ] A/B test different strategies

### Phase 3: Production Rollout (Week 4)
- [ ] Gradual rollout (10% → 50% → 100%)
- [ ] Monitor crash rates
- [ ] Track performance metrics
- [ ] Collect user ratings
- [ ] Adjust as needed

---

## 📞 Support

If you encounter issues:
1. Check logs for error messages
2. Verify database schema matches entities
3. Ensure all dependencies are injected
4. Review ALGORITHM_QUICK_REFERENCE.md
5. Check ALGORITHM_IMPROVEMENTS.md for details

---

**Version:** 1.0  
**Last Updated:** November 16, 2025  
**Status:** Ready for Integration
