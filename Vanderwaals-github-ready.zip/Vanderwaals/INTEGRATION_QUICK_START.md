# Integration Quick Reference

## 🔍 What Changed?

### Database (Version 2 → 3)
```kotlin
// NEW TABLE
category_preferences (
    category: String,      // PRIMARY KEY
    likes: Int,           // Count of likes
    dislikes: Int,        // Count of dislikes
    views: Int,           // Total views
    lastShown: Long       // Timestamp (for diversity)
)

// UPDATED TABLE
user_preferences {
    + momentumVector: FloatArray  // NEW: For momentum learning
}
```

### New Components
- `CategoryPreference` entity
- `CategoryPreferenceDao` 
- `CategoryPreferenceRepository` + Impl
- `ExplorationStrategies` (UCB algorithm)

### Modified Components
- `VanderwaalsDatabase` (v3)
- `UpdatePreferencesUseCase` (tracks category feedback)
- `SelectNextWallpaperUseCase` (tracks views)
- `DatabaseModule` (provides DAO)
- `AppModule` (provides Repository)

---

## 🚀 How to Use

### Recording User Feedback
```kotlin
// Already integrated! Just use existing use case
updatePreferencesUseCase(wallpaper, FeedbackType.LIKE)
// This now also records categoryPreferenceRepository.recordLike(category)
```

### Selecting Wallpapers
```kotlin
// Already integrated! Just use existing use case
val wallpaper = selectNextWallpaperUseCase()
// This now also records categoryPreferenceRepository.recordView(category)
```

### Querying Category Stats (NEW)
```kotlin
// In ViewModel
@Inject categoryPreferenceRepository: CategoryPreferenceRepository

// Get all categories with preferences
categoryPreferenceRepository.getAllCategoryPreferences().collect { prefs ->
    // List<CategoryPreference>
}

// Get specific category
categoryPreferenceRepository.getCategoryPreference("nature").collect { pref ->
    // CategoryPreference?
}

// Get categories by preference score (sorted)
val topCategories = categoryPreferenceRepository.getCategoriesByPreference()
// List<String> sorted by score descending

// Get underutilized categories
val underutilized = categoryPreferenceRepository.getUnderutilizedCategories(
    minTimeSinceShown = 24.hours.inWholeMilliseconds
)
```

### Getting Category Score (NEW)
```kotlin
// Get preference score for a category
val score = categoryPreferenceRepository.getCategoryScore("nature")
// Returns: (likes - 2×dislikes) / (views + 1)
```

---

## 📊 Algorithm Features Now Available

### 1. Composite Similarity (70% embedding + 20% color + 10% category)
```kotlin
// In FindSimilarWallpapersUseCase or custom ranking
val similarity = similarityCalculator.calculateCompositeSimilarity(
    userEmbedding = preferences.preferenceVector,
    wallpaperEmbedding = wallpaper.embedding,
    userColorPreference = preferences.colorPreference,
    wallpaperColor = wallpaper.dominantColor,
    categoryScore = categoryPreferenceRepository.getCategoryScore(wallpaper.category)
)
```

### 2. Momentum Learning (smooth, stable updates)
```kotlin
// Already integrated in UpdatePreferencesUseCase
// Uses PreferenceUpdater.updateWithMomentum() automatically
// Stored in user_preferences.momentumVector
```

### 3. Temporal Diversity (avoid repetitive categories)
```kotlin
// Already integrated in SelectNextWallpaperUseCase
// Tracks recent categories and avoids showing same category back-to-back
```

### 4. UCB Exploration (balance exploration/exploitation)
```kotlin
// Available in ExplorationStrategies.kt
val selected = ExplorationStrategies.selectWithUCB(
    candidates = wallpapers,
    getScore = { categoryPreferenceRepository.getCategoryScore(it.category) },
    getTotalViews = { preferences.feedbackCount },
    confidenceParameter = 2.0f
)
```

---

## 🧪 Testing the Integration

### Test Category Tracking
```kotlin
// 1. Like a nature wallpaper
updatePreferencesUseCase(natureWallpaper, FeedbackType.LIKE)

// 2. Check category preference
val naturePref = categoryPreferenceRepository.getCategoryPreference("nature").first()
assert(naturePref?.likes == 1)
assert(naturePref?.views == 1)

// 3. Check preference score
val score = categoryPreferenceRepository.getCategoryScore("nature")
assert(score > 0.0) // Positive score for liked category
```

### Test View Tracking
```kotlin
// 1. Select a wallpaper
val wallpaper = selectNextWallpaperUseCase().getOrThrow()

// 2. Check category was recorded
val pref = categoryPreferenceRepository.getCategoryPreference(wallpaper.category).first()
assert(pref?.views ?: 0 > 0)
assert(pref?.lastShown ?: 0 > 0)
```

### Test Temporal Diversity
```kotlin
// Select multiple wallpapers
repeat(10) {
    val wallpaper = selectNextWallpaperUseCase().getOrThrow()
    println("Selected: ${wallpaper.category}")
    // Should see variety, not same category repeatedly
}
```

---

## 🔄 Migration Handling

### First Run (Fresh Install)
- Database created at version 3
- Empty category_preferences table
- Empty momentumVector in user_preferences

### Upgrade from v2
- MIGRATION_2_3 runs automatically
- Adds momentumVector column (default empty array)
- Creates category_preferences table
- Creates index on lastShown
- No data loss

### Rollback (if needed)
```kotlin
// In DatabaseModule.kt (for testing only)
.fallbackToDestructiveMigration()  // Already included
```

---

## 📈 Monitoring & Analytics

### Category Performance
```kotlin
// Get all categories sorted by preference
val rankedCategories = categoryPreferenceRepository.getCategoriesByPreference()
rankedCategories.forEach { category ->
    val pref = categoryPreferenceRepository.getCategoryPreference(category).first()
    println("$category: ${pref?.preferenceScore} (${pref?.likes}L/${pref?.dislikes}D/${pref?.views}V)")
}
```

### Exploration Stats
```kotlin
// Check how many categories are underutilized
val underutilized = categoryPreferenceRepository.getUnderutilizedCategories(
    minTimeSinceShown = 24.hours.inWholeMilliseconds
)
println("Underutilized categories: ${underutilized.size}")
```

---

## 🐛 Troubleshooting

### Category preferences not updating?
- Check that `updatePreferencesUseCase` is being called
- Verify database migration ran (check version = 3)
- Check Room database inspector in Android Studio

### Migration failed?
- Check logcat for Room migration errors
- Verify MIGRATION_2_3 is in MIGRATIONS array
- Try uninstalling app (dev only) for clean install

### Momentum vector not working?
- Check database has momentumVector column
- Verify PreferenceUpdater is using updateWithMomentum()
- Check that UserPreferences.momentumVector is not empty

---

## 📝 Code Locations

### Entities
- `data/entity/CategoryPreference.kt`
- `data/entity/UserPreferences.kt` (updated)

### DAOs
- `data/dao/CategoryPreferenceDao.kt`

### Repositories
- `data/repository/CategoryPreferenceRepository.kt`
- `data/repository/CategoryPreferenceRepositoryImpl.kt`

### Use Cases
- `domain/usecase/UpdatePreferencesUseCase.kt` (updated)
- `domain/usecase/SelectNextWallpaperUseCase.kt` (updated)
- `domain/usecase/FindSimilarWallpapersUseCase.kt` (updated)

### Algorithms
- `algorithm/SimilarityCalculator.kt` (updated)
- `algorithm/PreferenceUpdater.kt` (updated)
- `algorithm/ExplorationStrategies.kt` (new)

### DI
- `di/DatabaseModule.kt` (updated)
- `di/AppModule.kt` (updated)

### Database
- `data/VanderwaalsDatabase.kt` (v2→v3)

---

## ✅ Checklist for Pull Request

- [x] Database migration implemented (2→3)
- [x] New entity and DAO created
- [x] Repository layer implemented
- [x] Dependency injection configured
- [x] Use cases updated
- [x] Zero compilation errors
- [x] Documentation complete
- [ ] Unit tests written
- [ ] Integration tests written
- [ ] Manual testing performed
- [ ] Performance tested
- [ ] Code reviewed

---

## 🎯 Key Metrics to Track

1. **Category Diversity**: Std deviation of category views
2. **Preference Score Distribution**: Histogram of category scores
3. **Momentum Convergence**: How quickly preferences stabilize
4. **Exploration Rate**: % of time UCB chooses exploration
5. **User Satisfaction**: Correlation between category score and user retention

---

**Status**: READY FOR TESTING ✅
**Build**: Should compile without errors ✅
**Runtime**: Requires app restart for migration ✅
