# Vanderwaals Database Schema

## Entity Relationship Diagram

```
┌─────────────────────────────────────┐
│      WallpaperMetadata              │
│  (wallpaper_metadata)               │
├─────────────────────────────────────┤
│ 🔑 id: String                       │
│    url: String                      │
│    thumbnailUrl: String             │
│    source: String                   │
│ 📊 category: String [indexed]      │
│ 📊 brightness: Int [indexed]       │
│ 📊 source: String [indexed]        │
│    colors: List<String>             │
│    embedding: FloatArray (576)      │
│    resolution: String               │
│    attribution: String?             │
└─────────────────────────────────────┘
            ↑
            │ references
            │
┌───────────┴─────────────────────────┐
│      WallpaperHistory                │
│  (wallpaper_history)                 │
├──────────────────────────────────────┤
│ 🔑 id: Long (auto-generated)        │
│ 📊 wallpaperId: String [indexed]    │
│ 📊 appliedAt: Long [indexed]        │
│    removedAt: Long?                  │
│    userFeedback: String?             │
│    downloadedToStorage: Boolean      │
└──────────────────────────────────────┘

┌─────────────────────────────────────┐
│      UserPreferences                 │
│  (user_preferences)                  │
├─────────────────────────────────────┤
│ 🔑 id: Int = 1 (singleton)          │
│    mode: String                      │
│    preferenceVector: FloatArray(576) │
│    likedWallpaperIds: List<String>   │
│    dislikedWallpaperIds: List<String>│
│    feedbackCount: Int                │
│    epsilon: Float                    │
│    lastUpdated: Long                 │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│      DownloadQueueItem              │
│  (download_queue)                   │
├─────────────────────────────────────┤
│ 🔑 wallpaperId: String              │
│ 📊 priority: Float [indexed]        │
│ 📊 downloaded: Boolean [indexed]    │
│    retryCount: Int                   │
└─────────────────────────────────────┘
            │
            │ references
            ↓
┌─────────────────────────────────────┐
│      WallpaperMetadata              │
│  (wallpaper_metadata)               │
└─────────────────────────────────────┘
```

## Type Converters

```kotlin
Converters.kt (@ProvidedTypeConverter)
├── List<String> ↔ JSON String
│   └── Used for: colors, liked/disliked IDs
└── FloatArray ↔ JSON String
    └── Used for: embeddings (576 dims), preference vectors
```

## Table Details

### 1. wallpaper_metadata
**Purpose:** Store all wallpaper metadata from GitHub/Bing sources  
**Size:** ~6000 rows (grows weekly)  
**Indexes:** category, source, brightness  
**Key Operations:**
- Search by category
- Filter by brightness
- Similarity matching using embeddings

### 2. user_preferences
**Purpose:** Store learned user aesthetic preferences  
**Size:** 1 row (singleton)  
**Updates:** Replace on feedback  
**Key Operations:**
- Load on app start
- Update after each feedback
- Calculate similarity scores

### 3. wallpaper_history
**Purpose:** Track wallpaper application history  
**Size:** Up to 100 rows (auto-cleanup)  
**Indexes:** wallpaperId, appliedAt  
**Key Operations:**
- Display history UI
- Prevent duplicates
- Calculate implicit feedback
- Track user behavior

### 4. download_queue
**Purpose:** Manage background wallpaper downloads  
**Size:** Up to 50 rows (top priority)  
**Indexes:** priority, downloaded  
**Key Operations:**
- Sort by priority
- Filter pending downloads
- Retry failed downloads
- Re-rank after feedback

## Data Flow

```
1. Initial Load
   ┌──────────────────────────┐
   │ Download manifest.json   │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Insert WallpaperMetadata │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Initialize UserPreferences│
   └──────────────────────────┘

2. Personalization Flow
   ┌──────────────────────────┐
   │ User uploads wallpaper   │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Extract embedding        │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Update preferenceVector  │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Calculate similarities   │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Populate DownloadQueue   │
   └──────────────────────────┘

3. Wallpaper Application
   ┌──────────────────────────┐
   │ Select from queue        │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Apply wallpaper          │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Insert WallpaperHistory  │
   └──────────────────────────┘

4. Feedback Loop
   ┌──────────────────────────┐
   │ User likes/dislikes      │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Update WallpaperHistory  │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Update preferenceVector  │
   │ (EMA algorithm)          │
   └────────────┬─────────────┘
                ↓
   ┌──────────────────────────┐
   │ Re-rank DownloadQueue    │
   └──────────────────────────┘
```

## Storage Estimates

### Per Wallpaper Record:
- Metadata: ~2 KB (URL, colors, etc.)
- Embedding: 576 floats × 4 bytes = 2.3 KB
- **Total per wallpaper:** ~4.3 KB

### Total Database Size:
- 6000 wallpapers × 4.3 KB = **~26 MB**
- User preferences: ~2.5 KB
- History (100 entries): ~10 KB
- Download queue (50 entries): ~5 KB
- **Total:** ~26 MB (very reasonable for mobile)

## Performance Considerations

### Indexed Queries (Fast):
```sql
-- Category filtering
SELECT * FROM wallpaper_metadata WHERE category = 'gruvbox'

-- Brightness filtering
SELECT * FROM wallpaper_metadata WHERE brightness > 50

-- History lookup
SELECT * FROM wallpaper_history WHERE wallpaperId = 'xyz'

-- Queue sorting
SELECT * FROM download_queue ORDER BY priority DESC
```

### Full Scans (Acceptable):
```sql
-- Similarity calculation (in-memory after load)
-- Done via Kotlin code after fetching embeddings
```

## Migration Strategy

### Version 1 → Version 2 (Future):
```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        // Example: Add new column
        database.execSQL(
            "ALTER TABLE wallpaper_metadata ADD COLUMN tags TEXT"
        )
    }
}
```

## Testing Strategy

### Unit Tests (Completed):
- ✅ Type converters (25 tests)
- ✅ Null handling
- ✅ Round-trip conversions
- ✅ Edge cases

### Integration Tests (TODO):
- DAO operations
- Transaction handling
- Migration testing
- Concurrent access

### End-to-End Tests (TODO):
- Full personalization flow
- Feedback loop
- Queue management
- History cleanup

## Notes

- All timestamps are in milliseconds since epoch
- FloatArray uses content-based equality (custom equals/hashCode)
- Converters handle null gracefully with empty defaults
- History auto-cleans at 100 entries
- Queue auto-reranks after feedback
- Single user preferences row (id = 1)
