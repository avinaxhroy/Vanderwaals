# Testing Guide: Color Preferences & Context Tracking

## Quick Testing Checklist

### 1. Color Preference Tracking (5 min)

#### Test Scenario: Uncategorized Wallpaper
1. Find wallpaper with blank/missing category
2. Like the wallpaper (tap heart icon)
3. Check logs for color extraction:
   ```
   D/UpdatePreferences: Recording color likes for uncategorized wallpaper: [#FF5733, #3498DB, #2ECC71]
   ```
4. Like another wallpaper with similar colors
5. Verify color boost in logs:
   ```
   D/SelectNextWallpaper: Color boost: 0.070 (similarity=0.85, colors=[...])
   ```

#### Expected Behavior
- ✅ Top 3 colors extracted from palette
- ✅ Color preferences incremented in database
- ✅ Similar colors get positive boost in ranking
- ✅ Wallpapers with liked colors ranked higher

#### SQL Check (Optional)
```sql
SELECT * FROM color_preferences ORDER BY (likes - dislikes) DESC LIMIT 10;
```

---

### 2. Feedback Context Tracking (5 min)

#### Test Scenario: Like at Different Times
1. Like wallpaper in morning (before 12pm)
2. Check database for context:
   ```sql
   SELECT wallpaperId, userFeedback, feedbackContext 
   FROM wallpaper_history 
   WHERE userFeedback IS NOT NULL;
   ```
3. Example output:
   ```json
   {
     "timeOfDay": 9,
     "dayOfWeek": 3,
     "batteryLevel": 85,
     "screenBrightness": 200
   }
   ```

#### Expected Behavior
- ✅ Context captured on like action
- ✅ Context captured on dislike action
- ✅ Time of day: 0-23 (correct hour)
- ✅ Day of week: 1-7 (1=Monday)
- ✅ Battery level: 0-100 (%)
- ✅ Brightness: 0-255 (system value)
- ✅ Legacy entries work (null context)

---

### 3. Integration Test (10 min)

#### Test Flow: End-to-End
1. **Setup**: Fresh install or clear app data
2. **Like categorized wallpaper**: 
   - Category preference tracked
   - Context captured
3. **Like uncategorized wallpaper**:
   - Color preferences tracked
   - Context captured
4. **Change wallpaper**: 
   - Verify category boost for categorized
   - Verify color boost for uncategorized
5. **Check history screen**:
   - All liked wallpapers shown
   - Context stored but not displayed (future feature)

#### Log Verification
Enable verbose logging:
```kotlin
android.util.Log.setProperty("log.tag.SelectNextWallpaper", "VERBOSE")
android.util.Log.setProperty("log.tag.UpdatePreferences", "VERBOSE")
```

Look for:
```
D/SelectNextWallpaper: Content boost for 'nature': 0.150 (category boost)
D/SelectNextWallpaper: Content boost for '': 0.070 (color boost fallback)
D/UpdatePreferences: Recording category like: nature
D/UpdatePreferences: Recording color likes: [#FF5733, #3498DB, #2ECC71]
```

---

## Manual Database Inspection

### Check Color Preferences
```sql
-- View all color preferences
SELECT colorHex, likes, dislikes, views, 
       (likes - 2*dislikes) / (likes + dislikes + 1) as score
FROM color_preferences
ORDER BY score DESC;

-- View liked colors only
SELECT * FROM color_preferences WHERE likes > dislikes;
```

### Check Feedback Context
```sql
-- View feedback with context
SELECT 
    h.wallpaperId,
    h.userFeedback,
    h.feedbackContext,
    datetime(h.appliedAt/1000, 'unixepoch') as applied_time
FROM wallpaper_history h
WHERE h.feedbackContext IS NOT NULL;
```

### Verify Migrations
```sql
-- Check database version
PRAGMA user_version;  -- Should be 5

-- Check color_preferences table exists
SELECT name FROM sqlite_master WHERE type='table' AND name='color_preferences';

-- Check feedbackContext column exists
PRAGMA table_info(wallpaper_history);
```

---

## Edge Cases to Test

### 1. No Color Data
- Wallpaper with empty colors array
- Expected: Neutral boost (0.0)

### 2. Invalid Hex Colors
- Malformed hex codes in palette
- Expected: Skip invalid, use valid colors only

### 3. No Category, No Colors
- Completely missing metadata
- Expected: Neutral boost (0.0)

### 4. Battery/Brightness Unavailable
- Permissions denied or system unavailable
- Expected: Default values (50% battery, 128 brightness)

### 5. Context Capture Failure
- Exception during FeedbackContext.fromCurrentState()
- Expected: Graceful degradation, null context

---

## Performance Verification

### Color Similarity Computation
- Benchmark: ~1ms per wallpaper
- Check logs for timing:
  ```
  D/SelectNextWallpaper: Ranked 100 wallpapers in 125ms (1.25ms/wallpaper)
  ```

### Database Query Performance
- Color preference lookup: <1ms
- History update with context: <2ms
- Verify no significant slowdown in ranking

---

## Regression Testing

### Ensure No Breaking Changes
1. **Category boost still works**: 
   - Like wallpaper with category
   - Verify 15% weight boost applied
2. **Legacy history readable**:
   - Old entries without context load correctly
   - No crashes on null feedbackContext
3. **Embedding-based ranking**:
   - Visual similarity still primary (85%)
   - Content boost secondary (10-15%)

---

## Success Criteria

- ✅ All color preference operations work
- ✅ Context captured on every feedback event
- ✅ Database migrations successful (v3→v4→v5)
- ✅ No crashes or errors in logs
- ✅ Performance within acceptable range (<2ms overhead)
- ✅ Backward compatibility maintained
- ✅ Privacy preserved (no external data transmission)

---

## Troubleshooting

### Issue: Color boost not applied
**Check:**
1. Wallpaper has blank category?
2. Wallpaper has colors array populated?
3. User has liked colors in database?

### Issue: Context not captured
**Check:**
1. Permissions granted (battery, brightness)?
2. Exception in FeedbackContext.fromCurrentState()?
3. Repository method updateHistoryWithContext() called?

### Issue: Database migration failed
**Check:**
1. Clean reinstall or use fallbackToDestructiveMigration
2. Check MIGRATIONS array includes all migrations
3. Verify SQL syntax in migration

---

## Quick Debug Commands

```bash
# View database in Android Studio
# Tools > Device File Explorer > data/data/me.avinas.vanderwaals/databases/

# Pull database to local
adb pull /data/data/me.avinas.vanderwaals/databases/vanderwaals_db.db

# View with SQLite browser
sqlite3 vanderwaals_db.db "SELECT * FROM color_preferences;"

# Check app logs
adb logcat | grep -E "SelectNextWallpaper|UpdatePreferences|MainViewModel"
```

---

## Testing Completed ✅

After running through this guide, you should have verified:
- [x] Color preference tracking for uncategorized wallpapers
- [x] Color similarity boost calculation (10% weight)
- [x] Feedback context capture (time, battery, brightness)
- [x] Database schema updated correctly (v5)
- [x] No performance degradation
- [x] Backward compatibility maintained
